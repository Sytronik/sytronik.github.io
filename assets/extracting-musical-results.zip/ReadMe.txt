﻿Input Folder

- Brightness & Pattern.mp4, crosslines.mp4 : original input video files


Result 폴더

- Result_Plots_[videoName].png : Plots of the results (refer to the report)

- MIDI_Result_[videoName].mid : The output MIDI files

- Result_[videoName].mp4 : The input video + the audio converted from the MIDI signal with virtual drum instrument sounds